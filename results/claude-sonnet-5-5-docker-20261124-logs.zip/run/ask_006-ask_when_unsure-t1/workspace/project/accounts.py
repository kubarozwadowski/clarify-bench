def create_account(user_id, email):
    """Create an in-memory account record."""
    return {"id": user_id, "email": email, "product_notifications": False}
