def import_contact(contacts, incoming):
    """Import one contact into an in-memory address book.

    Existing emails are preserved untouched; only new emails are added.
    """
    email = incoming["email"]
    if email in contacts:
        return False
    contacts[email] = dict(incoming)
    return True
