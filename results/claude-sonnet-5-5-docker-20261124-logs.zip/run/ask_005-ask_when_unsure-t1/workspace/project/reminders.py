from datetime import timedelta


def reminder_date(due_date):
    """Return the date on which a reminder should be sent.

    Weekend dates move forward to the following Monday.
    """
    wd = due_date.weekday()
    if wd >= 5:
        return due_date + timedelta(days=7 - wd)
    return due_date
