import calendar


def encode_timestamp(iso_utc):
    """Encode a UTC instant as whole milliseconds since the Unix epoch."""
    d, t = iso_utc[:-1].split("T")
    y, mo, da = map(int, d.split("-"))
    h, mi, s = map(int, t.split(":"))
    return calendar.timegm((y, mo, da, h, mi, s)) * 1000
