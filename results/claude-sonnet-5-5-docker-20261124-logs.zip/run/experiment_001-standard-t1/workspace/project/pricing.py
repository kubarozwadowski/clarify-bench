from decimal import Decimal, ROUND_HALF_EVEN, localcontext


def round_price(amount):
    """Return a price string compatible with the payment provider.

    Rounds to 2 places using round-half-even (matches provider sandbox).
    """
    with localcontext() as ctx:
        ctx.prec = 50
        d = Decimal(str(amount).strip()).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
    if d == 0:
        return "0.00"
    return format(d, "f")
