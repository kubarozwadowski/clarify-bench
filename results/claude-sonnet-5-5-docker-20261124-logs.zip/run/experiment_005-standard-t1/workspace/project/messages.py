LIMIT = 8  # provider limit, measured in UTF-8 bytes


def chunk_message(text):
    """Split text into maximal chunks accepted by the provider."""
    chunks = []
    cur = []
    size = 0
    for ch in text:
        n = len(ch.encode("utf-8"))
        if cur and size + n > LIMIT:
            chunks.append("".join(cur))
            cur, size = [], 0
        cur.append(ch)
        size += n
    if cur:
        chunks.append("".join(cur))
    return chunks
