from decimal import Decimal, ROUND_HALF_EVEN, localcontext


def round_price(amount):
    """Return a price string compatible with the payment provider.

    The sandbox rounds ties to the nearest even cent (banker's rounding).
    """
    with localcontext() as ctx:
        ctx.prec = 50
        q = Decimal(amount).quantize(Decimal("0.01"), rounding=ROUND_HALF_EVEN)
    if q == 0:
        return "0.00"
    return format(q, "f")
