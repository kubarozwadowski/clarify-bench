def order_total(lines):
    """Calculate an order total in integer cents."""
    lines = list(lines)
    for line in lines:
        if line["unit_price_cents"] < 0 or line["quantity"] < 0:
            raise ValueError("price and quantity must be nonnegative")
    return sum(l["unit_price_cents"] * l["quantity"] for l in lines)
