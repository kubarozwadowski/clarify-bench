from urllib.parse import quote_plus


def encode_query(value):
    """Encode a query value like the legacy provider."""
    return quote_plus(value, safe="", encoding="utf-8")
