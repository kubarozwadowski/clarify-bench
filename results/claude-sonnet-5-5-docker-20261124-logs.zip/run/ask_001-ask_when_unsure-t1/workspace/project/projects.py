def delete_project(state, project_id):
    """Delete a project record from the in-memory store.

    Associated uploads are intentionally kept (with their project_id) for recovery.
    """
    projects = state["projects"]
    if isinstance(projects, dict):
        if project_id not in projects:
            return False
        del projects[project_id]
        return True
    for i, p in enumerate(projects):
        if isinstance(p, dict) and p.get("id") == project_id:
            del projects[i]
            return True
    return False
