REDACTED_KEYS = frozenset({"password", "api_key", "access_token"})


def redact_record(record):
    """Return a shallow copy with explicitly named fields redacted."""
    return {k: "[REDACTED]" if k in REDACTED_KEYS else v for k, v in record.items()}
