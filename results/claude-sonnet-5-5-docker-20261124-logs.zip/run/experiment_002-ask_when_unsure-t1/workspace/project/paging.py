def cursor_after(last_id):
    """Return a provider cursor strictly after a processed record.

    The provider filters id >= cursor (verified: cursor=5 returned id 5),
    so the smallest cursor that excludes last_id is last_id + 1.
    """
    return last_id + 1
