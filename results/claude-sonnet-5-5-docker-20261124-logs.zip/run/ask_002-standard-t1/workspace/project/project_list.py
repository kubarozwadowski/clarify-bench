def list_projects(projects):
    """Return projects newest first (created_at desc), ties by id asc."""
    return sorted(projects, key=lambda p: (-p["created_at"], p["id"]))
