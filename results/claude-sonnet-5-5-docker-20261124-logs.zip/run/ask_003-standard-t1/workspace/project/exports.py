from datetime import timedelta

_OFFSET = timedelta(hours=-5)  # fixed UTC-05:00, no DST


def export_rows(events):
    """Return human-facing event export rows."""
    return [
        {
            "id": e["id"],
            "starts_at": (e["starts_at"] + _OFFSET).strftime("%Y-%m-%d %H:%M"),
        }
        for e in events
    ]
