def sort_names(names):
    """Sort names using the provider's stable comparison convention (casefold)."""
    return sorted(names, key=str.casefold)
