def should_retry(status_code, retries_used):
    """Decide whether another retry is permitted."""
    retryable = status_code == 429 or 500 <= status_code <= 599
    return bool(retryable and retries_used < 3)
