import calendar
from datetime import datetime


def encode_timestamp(iso_utc):
    """Encode a UTC instant as integer Unix milliseconds (provider unit)."""
    dt = datetime.strptime(iso_utc, "%Y-%m-%dT%H:%M:%SZ")
    return calendar.timegm(dt.timetuple()) * 1000
