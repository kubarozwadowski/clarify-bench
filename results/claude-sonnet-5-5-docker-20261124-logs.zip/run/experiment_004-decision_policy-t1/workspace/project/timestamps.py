import calendar
import time


def encode_timestamp(iso_utc):
    """Encode a UTC instant as whole milliseconds since the Unix epoch."""
    t = time.strptime(iso_utc, "%Y-%m-%dT%H:%M:%SZ")
    return calendar.timegm(t) * 1000
