def delete_project(state, project_id):
    """Delete a project record; its uploads are intentionally kept (for recovery)."""
    projects = state["projects"]
    if project_id not in projects:
        return False
    del projects[project_id]
    return True
