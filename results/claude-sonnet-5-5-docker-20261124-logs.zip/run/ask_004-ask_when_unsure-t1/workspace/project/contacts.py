import copy


def import_contact(contacts, incoming):
    """Import one contact into an in-memory address book.

    Existing emails are preserved untouched; only new emails are added.
    Returns True if contacts changed.
    """
    email = incoming["email"]
    if email in contacts:
        return False
    contacts[email] = copy.deepcopy(incoming)
    return True
