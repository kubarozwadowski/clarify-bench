import urllib.parse

def encode_query(value):
    """Encode a query value like the legacy provider."""
    # UTF-8 encode the value
    utf8_value = value.encode('utf-8')
    
    # Percent-escape using uppercase hex, preserving ASCII letters, digits, and -._~
    # urllib.parse.quote is used with safe='-_~' to preserve these characters
    # and uppercase=True to ensure uppercase hex in percent-encoding
    encoded = urllib.parse.quote(utf8_value, safe='-_~')
    
    # Convert to uppercase hex
    encoded = encoded.upper()
    
    # Replace spaces with +
    encoded = encoded.replace('%20', '+').replace('+', '%20')
    
    return encoded
