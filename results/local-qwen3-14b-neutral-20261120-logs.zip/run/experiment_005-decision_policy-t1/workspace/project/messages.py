def chunk_message(text):
    """Split text into maximal chunks accepted by the provider."""
    chunks = []
    i = 0
    while i < len(text):
        # Take up to 8 code points
        chunk = text[i:i+8]
        chunks.append(chunk)
        i += 8
    return chunks