def redact_record(record):
    """Return a shallow copy with explicitly named fields redacted."""
    redacted = record.copy()
    for key in ["password", "api_key", "access_token"]:
        if key in redacted:
            redacted[key] = "[REDACTED]"
    return redacted
