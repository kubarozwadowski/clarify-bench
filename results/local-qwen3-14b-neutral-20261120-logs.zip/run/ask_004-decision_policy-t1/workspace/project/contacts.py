def import_contact(contacts, incoming):
    """Import one contact into an in-memory address book."""
    email = incoming["email"]
    if email not in contacts:
        contacts[email] = {"email": email, "name": incoming["name"]}
        return True
    return False
