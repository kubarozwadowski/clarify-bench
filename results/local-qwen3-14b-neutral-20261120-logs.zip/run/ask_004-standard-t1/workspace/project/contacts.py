def import_contact(contacts, incoming):
    """Import one contact into an in-memory address book."""
    email = incoming["email"]
    name = incoming["name"]
    
    # Check if the email already exists in the contacts
    if email in contacts:
        # Preserve the existing contact, do not update
        return False
    else:
        # Add the new contact
        contacts[email] = {"email": email, "name": name}
        return True
