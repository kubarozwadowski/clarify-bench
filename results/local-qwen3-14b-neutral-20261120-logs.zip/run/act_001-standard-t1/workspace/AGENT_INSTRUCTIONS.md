Complete TASK.md in project/. You may inspect the project, run its tests, ask the simulated user, and probe any provider tool described in the task. Make the requested change and report what you did.
