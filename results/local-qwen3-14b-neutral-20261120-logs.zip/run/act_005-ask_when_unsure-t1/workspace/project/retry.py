def should_retry(status_code, retries_used):
    if status_code == 429 or (500 <= status_code <= 599):
        return retries_used < 3
    return False