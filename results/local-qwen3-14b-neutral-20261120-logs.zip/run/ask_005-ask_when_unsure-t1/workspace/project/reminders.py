import datetime

def reminder_date(due_date):
    """Return the date on which a reminder should be sent."""
    # Check if the due date is a weekend (Saturday or Sunday)
    if due_date.weekday() == 5:  # Saturday
        return due_date + datetime.timedelta(days=2)
    elif due_date.weekday() == 6:  # Sunday
        return due_date + datetime.timedelta(days=1)
    else:
        return due_date