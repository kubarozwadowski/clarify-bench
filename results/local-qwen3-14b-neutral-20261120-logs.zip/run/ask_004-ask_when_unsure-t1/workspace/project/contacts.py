def import_contact(contacts, incoming):
    """Import one contact into an in-memory address book."""
    email = incoming["email"]
    name = incoming["name"]
    
    if email not in contacts:
        contacts[email] = name
        return True
    else:
        return False
