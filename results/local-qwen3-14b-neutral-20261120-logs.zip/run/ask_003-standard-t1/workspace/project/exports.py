from datetime import datetime, timezone

def export_rows(events):
    """Return human-facing event export rows."""
    result = []
    for event in events:
        # Extract id and starts_at from the event
        event_id = event["id"]
        starts_at = event["starts_at"]
        
        # Format starts_at as YYYY-MM-DD HH:MM
        formatted_time = starts_at.strftime("%Y-%m-%d %H:%M")
        
        # Create a new row with id and formatted starts_at
        row = {"id": event_id, "starts_at": formatted_time}
        result.append(row)
    return result
