def delete_project(state, project_id):
    """Delete a project from the in-memory store."""
    # Check if the project exists
    if project_id in state['projects']:
        # Remove the project from the projects dictionary
        del state['projects'][project_id]
        # Return True to indicate the project was deleted
        return True
    # Return False if the project does not exist
    return False