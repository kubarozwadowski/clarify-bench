def list_projects(projects):
    """Return projects in their default display order."""
    # Return a new list sorted by the created_at field in ascending order
    return sorted(projects, key=lambda x: x['created_at'])
