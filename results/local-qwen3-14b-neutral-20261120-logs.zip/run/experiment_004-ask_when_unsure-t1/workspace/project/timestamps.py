from datetime import datetime

def encode_timestamp(iso_utc):
    """Encode a UTC instant in the provider's timestamp representation."""
    dt = datetime.fromisoformat(iso_utc)
    # Convert to Unix timestamp in milliseconds
    return int(dt.timestamp() * 1000)