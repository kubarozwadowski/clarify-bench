def list_projects(projects):
    """Return projects in their default display order."""
    # Create a new list to avoid mutating the input
    sorted_projects = sorted(projects, key=lambda x: x['created_at'])
    return sorted_projects
