def sort_names(names):
    """Sort names using the provider's stable comparison convention."""
    return sorted(names)