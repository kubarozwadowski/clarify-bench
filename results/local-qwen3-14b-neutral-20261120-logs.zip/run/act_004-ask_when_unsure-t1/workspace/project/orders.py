def order_total(lines):
    """Calculate an order total in integer cents."""
    total = 0
    for line in lines:
        unit_price_cents = line['unit_price_cents']
        quantity = line['quantity']
        if unit_price_cents < 0 or quantity < 0:
            raise ValueError("Negative price or quantity")
        total += unit_price_cents * quantity
    return total
