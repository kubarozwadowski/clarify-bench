def clamp_quantity(value, minimum=1, maximum=99):
    """Return a quantity within the supplied bounds."""
    if minimum > maximum:
        raise ValueError("Minimum cannot be greater than maximum.")
    if value < minimum:
        return minimum
    if value > maximum:
        return maximum
    return value