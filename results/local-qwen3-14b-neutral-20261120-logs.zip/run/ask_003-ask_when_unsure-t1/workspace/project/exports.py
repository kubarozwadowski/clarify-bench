from datetime import datetime, timezone

def export_rows(events):
    """Return human-facing event export rows."""
    result = []
    for event in events:
        # Format starts_at as YYYY-MM-DD HH:MM without timezone suffix
        starts_at = event['starts_at'].replace(tzinfo=None)
        formatted_time = starts_at.strftime('%Y-%m-%d %H:%M')
        
        # Create a new row with id and formatted starts_at
        row = {
            'id': event['id'],
            'starts_at': formatted_time
        }
        result.append(row)
    return result
