def sort_names(names):
    """Sort names using the provider's stable comparison convention."""
    return sorted(names, key=lambda x: x.casefold())
