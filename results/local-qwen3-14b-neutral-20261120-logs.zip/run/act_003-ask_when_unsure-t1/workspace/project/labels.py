def unique_labels(labels):
    """Return distinct labels in first-occurrence order."""
    seen = set()
    result = []
    for label in labels:
        if label not in seen:
            seen.add(label)
            result.append(label)
    return result
