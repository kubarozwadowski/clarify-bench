def cursor_after(last_id):
    """Return a provider cursor strictly after a processed record."""
    return last_id + 1
