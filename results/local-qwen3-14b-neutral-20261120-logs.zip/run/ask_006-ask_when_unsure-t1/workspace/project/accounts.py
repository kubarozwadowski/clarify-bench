def create_account(user_id, email):
    return {
        'id': user_id,
        'email': email,
        'product_notifications': False
    }